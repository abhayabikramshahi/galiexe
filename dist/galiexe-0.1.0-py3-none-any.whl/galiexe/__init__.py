from .core import galiexe

if __name__ == "__main__":
    print("\033[95m==============================\033[0m")
    print("\033[94m  Welcome to Galiexe!  \033[0m")
    print("\033[95m==============================\033[0m")
    print("\nGet a random Nepali gali (slang) every time you run!\n")
    print("\033[92mYour gali:\033[0m", galiexe())
    print("\n\033[93mTip: Import galiexe and call galiexe() to get a random gali in your code!\033[0m")
